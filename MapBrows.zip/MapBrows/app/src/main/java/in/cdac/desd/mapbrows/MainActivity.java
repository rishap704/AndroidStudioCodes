package in.cdac.desd.mapbrows;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(
                MainActivity.this,
                new String[] {
                        Manifest.permission.CALL_PHONE
                },
                101
        );
    }

    public void startBrowser(View view) {
        Uri uri = Uri.parse("https://google.com");
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                uri
        );
        startActivity(intent);             //to fire intent on android system
    }

    public void startMap(View view) {
        Uri uri = Uri.parse("geo:0.0,7.9");
        Intent intent = new Intent(
                Intent.ACTION_TIME_TICK,
                uri
        );
        startActivity(intent);             //to fire intent on android system
    }

    public void dialNum(View view) {
        Uri uri = Uri.parse("tel:6387548469");
        Intent intent = new Intent(
                Intent.ACTION_DIAL,
                uri
        );
        startActivity(intent);             //to fire intent on android system
    }

    public void callNum(View view) {

        Uri uri = Uri.parse("tel:6387548469");
        Intent intent = new Intent(
                Intent.ACTION_CALL,
                uri
        );
        startActivity(intent);             //to fire intent on android system
    }

}
