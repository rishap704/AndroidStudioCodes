package in.cdac.desd.day5_appmultipleactivity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnStartTestAct;
    Button btnext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnStartTestAct=findViewById(R.id.btnStartTestAct);  //registering the button
        btnext=findViewById(R.id.btnexit);
        // THIS IS THE INTENT EXPLICIT APPROACH
        btnStartTestAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                  MainActivity.this,     // Package context
                  TestActivity.class                 // Target Activity class name
                );
                startActivity(intent);
            }
        });
        btnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dia = new AlertDialog.Builder(MainActivity.this);
                dia.setMessage("Are u sure to exit");
                dia.setIcon(R.drawable.joker1);
                dia.setTitle("ALERT");

                dia.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        MainActivity.this.finish();

                    }
                });

                dia.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                dia.show();
               // MainActivity.this.finish();
            }
        });
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_BACK)
        {
            Toast.makeText(
                    MainActivity.this,
                    "Pls dont use hardware back button",
                    Toast.LENGTH_SHORT
            ).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
