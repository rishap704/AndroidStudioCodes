package in.cdac.desd.day4_app1_toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button btShowT;
        final TextView tvBtnClick;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btShowT=findViewById(R.id.btnShowToast);
        tvBtnClick=findViewById(R.id.textBtnClick);

        //this api helps to describe an action to be done when the Button is clicked
//        btShowT.setOnClickListener(new View.OnClickListener() {                 //this is anonymous class definition as a parameter of function call
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(MainActivity.this,
//                        "BUTTON CLICK",      //the text to be displayed
//                        Toast.LENGTH_LONG     //Duration of the text to be display on screen//
//                ).show();
//            }
//        });


    btShowT.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            boolean app_dis;
            if(tvBtnClick.getVisibility()==View.VISIBLE) {
               // tvBtnClick.append("_hello_",0,7);
                tvBtnClick.setVisibility(View.INVISIBLE);
            }
            else {
                tvBtnClick.setVisibility(View.VISIBLE);
            }
        }
    });
    }
}
