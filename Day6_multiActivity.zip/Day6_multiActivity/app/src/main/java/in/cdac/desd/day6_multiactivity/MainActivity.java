package in.cdac.desd.day6_multiactivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnStartFirstAct;
    EditText editName;
    EditText editAge;
    TextView tvShowFeedback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnStartFirstAct=findViewById(R.id.btnStartTestAct);
        editAge=findViewById(R.id.edtAge);
        editName=findViewById(R.id.edtName);
        tvShowFeedback=findViewById(R.id.textShowFeedback);

        btnStartFirstAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
     //this is the Explicit Intent

                String name = editName.getText().toString();
                String testName = editAge.getText().toString();
                int age = Integer.parseInt(testName);
                editAge.setText("");
                editName.setText("");
                String action = "desdaction1";
                Intent intent = new Intent(action);           // creating a intent object
                intent.putExtra("KEY_AGE",age );        // Firing and intent with a KEY as KEY_AGE and VALUE as age this can be received by other activities
                intent.putExtra("KEY_NAME",name );
                //startActivity(intent);
                startActivityForResult(intent,11);
            }
        });


    }

    // THIS is A compulsary implementation of onActivityResult method  because we are using a :: startActivityForResult(intent,11);
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 11 && resultCode == RESULT_OK)          // we are matching the correct request
        {
            String feedback = data.getStringExtra("KEY_FEEDBACK");
            tvShowFeedback.setVisibility(View.VISIBLE);
            tvShowFeedback.setText("Feedback:"+feedback);
            tvShowFeedback.setTextColor(Color.RED);
        }
    }
}
