package in.cdac.desd.day6_multiactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FirstActivity extends AppCompatActivity {
    Button btnBack;
    TextView tvName,tvAge;
    EditText etFeedback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        btnBack=findViewById(R.id.btnBack);
        tvAge=findViewById(R.id.TextAge);
        tvName=findViewById(R.id.TextName);
        etFeedback=findViewById(R.id.editFeedback);

        Intent revIntent=getIntent();

        String recName = revIntent.getStringExtra("KEY_NAME");
        int recAge =revIntent.getIntExtra("KEY_AGE",0);
        tvName.setText("NAME:"+recName);
        tvAge.setText("AGE:"+recAge);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String feedback = etFeedback.getText().toString();  // to read the String from FEEDBACK
                Intent retIntent=new Intent();
                retIntent.putExtra("KEY_FEEDBACK",feedback);  // FIRING THE
                setResult(RESULT_OK,retIntent);            // this RESult ok help to check the Parsing at the REceiver side

                FirstActivity.this.finish();
            }
        });
    }
}
