package in.cdac.desd.day5_calcapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnAdd,btnDiv;
    EditText etInput1,etInput2;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Registering the views by thier ID
        etInput1=findViewById(R.id.edit_id1);
        etInput2=findViewById(R.id.edit_id2);
        btnAdd=findViewById(R.id.btnPlus);
        btnDiv=findViewById(R.id.btnDiv);
        tvResult=findViewById(R.id.textResult);
        buttonlistner();
    }
    //this is our own method which can be called in OnCreate
    private void buttonlistner(){
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String i1=etInput1.getText().toString();   // getting the user input value 1
                int val1=Integer.parseInt(i1);       // converting the string value into integer using the integer class
                int val2=Integer.parseInt(etInput2.getText().toString());

                etInput1.setText("");    // to clear the input fields
                etInput2.setText("");    // to clear the input fields
                int result=val1+val2;
                tvResult.setText("Result:"+result);   // print the result in the text VIEW
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String i1=etInput1.getText().toString();   // getting the user input value 1
                int val1=Integer.parseInt(i1);       // converting the string value into integer using the integer class
                int val2=Integer.parseInt(etInput2.getText().toString());
                etInput1.setText("");    // to clear the input fields
                etInput2.setText("");    // to clear the input fields
                float result=(float) val1/val2;
                tvResult.setText("Result:"+result);   // print the result in the text VIEW
            }
        });
    }
}
